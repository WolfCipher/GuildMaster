# GuildMaster
A medieval fantasy game where you play as a master of a guild associated with a goddess.
